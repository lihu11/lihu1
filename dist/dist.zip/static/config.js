console.log('load config.js')

var jQuery = {
  name: 'hello'
}
